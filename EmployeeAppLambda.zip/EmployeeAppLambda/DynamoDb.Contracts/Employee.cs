﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace DynamoDb.Contracts
{
    [DynamoDBTable("Employee")]
    public class Employee
    {
        [DynamoDBProperty("Id")]
        [DynamoDBHashKey]
        public Guid Id { get; set; }

        [DynamoDBProperty("Name")]
        public string Name { get; set; }

        [DynamoDBProperty("Grade")]
        public string Grade { get; set; }

    }
}
