﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DynamoDb.Contracts
{
    public class EmployeeViewModel
    {
        public IEnumerable<Employee> Employee { get; set; }
        public ResultsType ResultsType { get; set; }
        public string PaginationToken { get; set; }
    }
}
