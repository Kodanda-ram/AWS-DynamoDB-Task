﻿namespace DynamoDb.Contracts
{
    public enum ResultsType
    {
        List,
        Search
    }
}
