﻿namespace DynamoDb.Contracts
{
    public enum InputType
    {
        Create,
        Update
    };
}
