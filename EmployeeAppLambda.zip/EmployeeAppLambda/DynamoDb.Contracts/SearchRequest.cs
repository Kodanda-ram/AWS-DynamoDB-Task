﻿namespace DynamoDb.Contracts
{
    public class SearchRequest
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
    }
}