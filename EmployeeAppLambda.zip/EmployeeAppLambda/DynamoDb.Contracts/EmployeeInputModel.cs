﻿namespace DynamoDb.Contracts
{
    public class EmployeeInputModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
        public InputType InputType { get; set; }
    }
}
