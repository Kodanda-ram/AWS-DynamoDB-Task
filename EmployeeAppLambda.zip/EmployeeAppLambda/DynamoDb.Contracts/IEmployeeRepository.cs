﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DynamoDb.Contracts.Interfaces
{
    public interface IEmployeeRepository
    {
        Task<Employee> Single(Guid employeeId);
        Task<EmployeeViewModel> All(string paginationToken = "");
        Task<IEnumerable<Employee>> Find(SearchRequest searchReq);
        Task Add(EmployeeInputModel entity);
        Task Remove(Guid employeeId);
        Task Update(Guid employeeId, EmployeeInputModel entity);
    }
}
