﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using DynamoDb.Contracts;
using DynamoDb.Contracts.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DynamoDb.Core
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly IAmazonDynamoDB dynamoDBClient;
        private readonly IDynamoDBContext dynamoDBContext;
        private readonly AmazonDynamoDBClient _client;
        private readonly DynamoDBContext _context;

        public EmployeeRepository(IAmazonDynamoDB _dynamoDBClient, IDynamoDBContext _dynamoDBContext)
        {
            _client = new AmazonDynamoDBClient();
            _context = new DynamoDBContext(_client);

            this.dynamoDBClient = _dynamoDBClient;
            this.dynamoDBContext = _dynamoDBContext;
        }

        public async Task Add(EmployeeInputModel entity)
        {
            var employee = new Employee
            {
                Id = Guid.NewGuid(),
                Name = entity.Name,
                Grade = entity.Grade
            };

            await _context.SaveAsync<Employee>(employee);
        }

        public async Task<EmployeeViewModel> All(string paginationToken = "")
        {
            // Get the Table ref from the Model
            var table = _context.GetTargetTable<Employee>();

            // If there's a PaginationToken
            // Use it in the Scan options
            // to fetch the next set
            var scanOps = new ScanOperationConfig();
            
            if (!string.IsNullOrEmpty(paginationToken))
            {
                scanOps.PaginationToken = paginationToken;
            }

            // returns the set of Document objects
            // for the supplied ScanOptions
            var results = table.Scan(scanOps);
            List<Document> data = await results.GetNextSetAsync();

            // transform the generic Document objects
            // into our Entity Model
            IEnumerable<Employee> employees = _context.FromDocuments<Employee>(data);

            // Pass the PaginationToken
            // if available from the Results
            // along with the Result set
            return new EmployeeViewModel
            {
                PaginationToken = results.PaginationToken,
                Employee = employees,
                ResultsType = ResultsType.List
            };

            /* The Non-Pagination approach */
            //var scanConditions = new List<ScanCondition>() { new ScanCondition("Id", ScanOperator.IsNotNull) };
            //var searchResults = _context.ScanAsync<Reader>(scanConditions, null);
            //return await searchResults.GetNextSetAsync();
        }

        public async Task<IEnumerable<Employee>> Find(SearchRequest searchReq)
        {
            var scanConditions = new List<ScanCondition>();
            if (!string.IsNullOrEmpty(searchReq.Name))
                scanConditions.Add(new ScanCondition("Name", ScanOperator.Equal, searchReq.Name));
            if (!string.IsNullOrEmpty(searchReq.Grade))
                scanConditions.Add(new ScanCondition("Grade", ScanOperator.Equal, searchReq.Grade));

            return await _context.ScanAsync<Employee>(scanConditions, null).GetRemainingAsync();
        }

        public async Task Remove(Guid employeeId)
        {
            await _context.DeleteAsync<Employee>(employeeId);
        }

        public async Task<Employee> Single(Guid employeeId)
        {
            return await _context.LoadAsync<Employee>(employeeId); 
        }

        public async Task Update(Guid employeeId, EmployeeInputModel entity)
        {
            var employee = await Single(employeeId);

            employee.Name = entity.Name;
            employee.Grade = entity.Grade;

            await _context.SaveAsync<Employee>(employee);
        }
    }
}
