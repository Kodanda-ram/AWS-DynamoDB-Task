﻿using System;
using System.Threading.Tasks;
using DynamoDb.Contracts;
using DynamoDb.Contracts.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DynamoDb.EmployeeApp.Controllers
{
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        private IEmployeeRepository _repository;

        public EmployeeController(IEmployeeRepository repository)
        {
            _repository = repository;
        }

        // GET: EmployeeController
        public async Task<ActionResult> Index(string name = "")
        {
            if (!string.IsNullOrEmpty(name))
            {
                var employee = await _repository.Find(new SearchRequest { Name = name });
                return View(new EmployeeViewModel
                {
                    Employee = employee,
                    ResultsType = ResultsType.Search
                });
            }
            else
            {
                var employee = await _repository.All();
                return View(employee);
            }
        }

        [HttpGet]
        [Route("Create")]
        public IActionResult Create()
        {
            return View("~/Views/Employee/CreateOrUpdate.cshtml");
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [Route("Create")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(EmployeeInputModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return View("~/Views/Employee/CreateOrUpdate.cshtml", model);

                await _repository.Add(model);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View("~/Views/Employee/CreateOrUpdate.cshtml", model);
            }
        }

        [HttpGet]
        [Route("Edit/{employeedId}")]
        public async Task<ActionResult> Edit(Guid employeedId)
        {
            var employee = await _repository.Single(employeedId);

            ViewBag.Id = employeedId;

            return View("~/Views/Employee/CreateOrUpdate.cshtml", new EmployeeInputModel
            {
                Name = employee.Name,
                Grade = employee.Grade,
                InputType = InputType.Update
            });
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [Route("Edit/{employeeId}")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Guid employeeId, EmployeeInputModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return View("~/Views/Employee/CreateOrUpdate.cshtml", model);

                await _repository.Update(employeeId, model);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View("~/Views/Employee/CreateOrUpdate.cshtml", model);
            }
        }

        [HttpGet]
        [Route("Delete/{employeeId}")]
        public async Task<ActionResult> Delete(Guid employeeId)
        {
            await _repository.Remove(employeeId);

            return RedirectToAction(nameof(Index));
        }
    }
}
