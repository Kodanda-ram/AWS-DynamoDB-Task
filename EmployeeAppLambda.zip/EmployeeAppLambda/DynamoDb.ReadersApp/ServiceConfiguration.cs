﻿namespace DynamoDb.ReadersApp
{
    internal class ServiceConfiguration
    {
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }
    }
}