using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.S3;
using AWSServerlessDB.Modals;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace AWSServerlessDB.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : ControllerBase
    {

        private static IAmazonDynamoDB dynamoDBClient;
        private static IDynamoDBContext dynamoDbContext;
        IAmazonS3 S3Client { get; set; }

        private readonly ILogger<ValuesController> _logger;

        private const string TableName = "Employee";
                
        public ValuesController(IOptions<ServiceConfiguration> settings,  ILogger<ValuesController> logger, IAmazonDynamoDB _dynamoDBClient, IDynamoDBContext _dynamoDbContext)
        {
            _logger = logger;

            dynamoDBClient = _dynamoDBClient;
            dynamoDbContext = _dynamoDbContext;

        }


        // GET api/values
        [HttpGet]
        public async Task<List<string>> Get()
        {
            try
            {
                List<string> list = new List<string>();
                var request = new ListTablesRequest
                {
                    Limit = 100
                };

                var response = await dynamoDBClient.ListTablesAsync(request);
                list = response.TableNames;

                return list;
                 
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        [HttpPost("SaveToEmployeeTable")]
        public async Task<Employee> SaveToDynamoDbEmployee(Employee obj)
        {
            try
            {
                var response = await SaveToDynamoDb(obj);
                return response;
            }

            catch (Exception) { throw; }
        }

        public async Task<T> SaveToDynamoDb<T>(T obj) where T : class
        {
            try
            {
                DynamoDBContext context = new DynamoDBContext(dynamoDBClient);
                await context.SaveAsync(obj);
                var response = await context.LoadAsync<T>(obj);
                return response;
            }

            catch (Exception) { throw; }
        }

        [HttpGet("Employee")]
        public async Task<List<Employee>> GetEmployee()
        {
            var response = await GetDynamoDBFullData<Employee>();
            return response;
        }

        public async Task<List<T>> GetDynamoDBFullData<T>() where T : class
        {
            DynamoDBContext contect = new DynamoDBContext(dynamoDBClient);
            var conditions = new List<ScanCondition>();

            var result = await contect.ScanAsync<T>(conditions).GetRemainingAsync();
            return result;
        }

        [HttpGet("GetEmployeeById /{id}")]
        public async Task<Employee> GetEmployeeById(int id)
        {
            try
            {
                var response = await GetDynamoDbDataById<Employee>(id);
                return response;
            }
            catch (Exception) { throw; }
        }

        public async Task<T> GetDynamoDbDataById<T>(int id) where T : class
        {
            try
            {
                DynamoDBContext contect = new DynamoDBContext(dynamoDBClient);
                //var conditions = new List<ScanCondition>();

                var result = await contect.LoadAsync<T>(id);
                return result;
            }

            catch (Exception) { throw; }
        }

        [HttpGet("Delete /{id}")]
        public async Task DeleteEmployee(int id)
        {
            await Delete<Employee>(id);
        }

        public async Task Delete<T>(int id) where T : class
        {
            try
            {
                DynamoDBContext contect = new DynamoDBContext(dynamoDBClient);

                await contect.DeleteAsync<T>(id);
            }

            catch (Exception) { throw; }
        }

    }
}
